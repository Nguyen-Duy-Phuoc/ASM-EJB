export class ResponseBase {
  Status: number;
  Message: string;
}
export interface LooseObject {
  [key: string]: any;
}

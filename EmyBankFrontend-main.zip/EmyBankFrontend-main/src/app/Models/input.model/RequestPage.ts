export class RequestPage{
   So_ban_ghi?:number
   Trang?:number
   pageSize?: number;
}
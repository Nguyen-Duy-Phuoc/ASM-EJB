export class RequestBase {
  RequestID: number;
  UserName: string;
}

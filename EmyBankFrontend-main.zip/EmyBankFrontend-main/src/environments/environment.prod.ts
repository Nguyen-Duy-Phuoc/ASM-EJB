export const environment = {
  production: true,
  APIURL: 'https://localhost:44319/',
};
